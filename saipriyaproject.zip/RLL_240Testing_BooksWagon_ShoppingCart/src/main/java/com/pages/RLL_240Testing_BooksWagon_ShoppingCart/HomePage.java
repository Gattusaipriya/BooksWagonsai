package com.pages.RLL_240Testing_BooksWagon_ShoppingCart;
import org.openqa.selenium.By; 
import org.openqa.selenium.WebDriver; 

public class HomePage { 
	WebDriver driver; 
	By myAccount = By.id("ctl00_lblUser"); 


	public HomePage(WebDriver driver) { 
		this.driver = driver; 
	} 

	public void launch() { 
		driver.get("https://www.bookswagon.com/"); 
	} 

	public void Click_MyAccount() { 
		driver.findElement(myAccount).click(); 
	} 

} 
