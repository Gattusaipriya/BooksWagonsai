package com.pages.RLL_240Testing_BooksWagon_ShoppingCart;

import org.openqa.selenium.By; 
import org.openqa.selenium.WebDriver; 


public class LoginPage { 
	WebDriver driver; 

	By MyAccount=By.xpath("//span[contains(text(),\"My Account\")]"); 
	By loginButton = By.xpath("//h3[contains(text(),\"Log in\")]"); 
	By emailField = By.xpath("//input[@id=\"ctl00_phBody_SignIn_txtEmail\"]"); 
	By passwordField = By.xpath("//input[@id=\"ctl00_phBody_SignIn_txtPassword\"]"); 
	By submitButton = By.xpath("//a[@id=\"ctl00_phBody_SignIn_btnLogin\"]"); 


	public LoginPage (WebDriver driver)  { 
		this.driver = driver;	 
	} 
	public void enter_emailfield(String lgn_mobile) throws InterruptedException { 
		driver.findElement(emailField).sendKeys(lgn_mobile); 
		Thread.sleep(1000); 
	} 
	public void enter_password(String password) throws InterruptedException { 
		driver.findElement(passwordField).sendKeys(password); 
		Thread.sleep(1000); 
	} 
	public void click_submitButtton() { 
		driver.findElement(submitButton).click(); 
	} 
} 


