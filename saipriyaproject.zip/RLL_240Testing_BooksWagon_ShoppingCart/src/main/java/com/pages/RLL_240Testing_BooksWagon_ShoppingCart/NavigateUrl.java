package com.pages.RLL_240Testing_BooksWagon_ShoppingCart;

import org.openqa.selenium.WebDriver; 
import org.openqa.selenium.WebElement; 
import org.openqa.selenium.support.FindBy; 
import org.openqa.selenium.support.PageFactory; 

public class NavigateUrl { 
	WebDriver driver; 
	public NavigateUrl(WebDriver driver) { 
		this.driver = driver; 
	} 
	public void Navigate() { 
		driver.navigate().to("https://www.bookswagon.com/search-books/the-secret"); 
	} 

}
