package com.JunitRunner;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;
@RunWith(Cucumber.class)
@CucumberOptions(
		features = "src/test/java/com/features/ShoppingCart",
		glue = "com.stepdefinitions.ShoppingCart", // Adjust to your package
		plugin = {"pretty", "html:target/cucumber-reports.html"},
		tags = " @homepage or @LoginPage or @NavigateUrl or @AddtoCart or @RemoveItem", 
		monochrome = true 
		)
public class JunitRunner {



}
