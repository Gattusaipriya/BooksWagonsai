package com.stepdefinitions.ShoppingCart;


import org.apache.log4j.Logger; 
import org.openqa.selenium.WebDriver; 
import org.openqa.selenium.chrome.ChromeDriver; 
import org.testng.Assert; 

import com.pages.RLL_240Testing_BooksWagon_ShoppingCart.NavigateUrl; 

import io.cucumber.java.Before; 
import io.cucumber.java.en.Given; 
import io.cucumber.java.en.Then; 
import io.cucumber.java.en.When; 

public class NavigateUrlSteps { 
	WebDriver driver; 
	NavigateUrl nu; 
	Logger log21; 

	@Before 
	public void init() { 
		driver = new ChromeDriver(); 
		nu=new NavigateUrl(driver); 
		log21 = Logger.getLogger(NavigateUrlSteps.class); 
	} 


	@Given("the user navigates to the application URL") 
	public void the_user_navigates_to_the_application_URL() { 
		nu.Navigate(); 
		log21.info("user navigates to application url"); 
	} 
	@When("the user enters the URL") 
	public void the_user_enters_the_URL() { 


	} 
	@Then("the user should access the application") 
	public void the_user_should_access_the_application() { 
		String expectedUrl = "https://www.bookswagon.com/search-books/the-secret"; 
		String actualUrl = driver.getCurrentUrl(); 
		Assert.assertEquals(actualUrl, expectedUrl, "User is not navigated to the expected URL"); 
		log21.info("user accessed the application"); 


	} 
} 
