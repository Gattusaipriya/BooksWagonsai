package com.stepdefinitions.ShoppingCart;

import org.apache.log4j.Logger;
import org.openqa.selenium.By; 
import org.openqa.selenium.WebDriver; 
import org.openqa.selenium.WebElement; 
import org.openqa.selenium.chrome.ChromeDriver; 
import org.testng.Assert; 

import com.pages.RLL_240Testing_BooksWagon_ShoppingCart.LoginPage; 

import io.cucumber.java.Before; 
import io.cucumber.java.en.Given; 
import io.cucumber.java.en.Then; 
import io.cucumber.java.en.When; 

public class LoginPageSteps { 
	WebDriver driver; 
	LoginPage lp;
	Logger log24;

	@Before 
	public void init() { 
		driver = new ChromeDriver(); 
		lp = new LoginPage(driver);
		log24=Logger.getLogger(LoginPageSteps.class);
	} 


	@Given("user in Login page") 
	public void user_in_login_page() throws InterruptedException { 
		log24.info("user in login page");

	} 

	@When("User Enters login_mobileno <lgn_mobile> {string}") 
	public void user_enters_login_mobileno(String lgn_mobile) throws InterruptedException { 
		lp.enter_emailfield(lgn_mobile); 
	} 

	@When("User Enters Password {string}") 
	public void user_enters_password(String password) throws InterruptedException { 
		lp.enter_password(password); 
	} 

	@When("User clicks on Login_button") 
	public void user_clicks_on_login_button() throws InterruptedException { 
		lp.click_submitButtton(); 
		log24.info("user click on login button");
	} 

	@Then("User can login successfully") 
	public void user_can_login_successfully() { 
		String expected = "My Account"; 
		WebElement actualElement = driver.findElement(By.xpath("//*[contains(text(),\"My Account\")]")); 
		String actualText = actualElement.getText(); 

		Assert.assertEquals(actualText, expected); 

		if (actualText.equals(expected)) { 
			System.err.println("User logged in Successfully"); 
		} else { 
			System.out.println("Invalid Credentials"); 
		} 
	} 
} 




