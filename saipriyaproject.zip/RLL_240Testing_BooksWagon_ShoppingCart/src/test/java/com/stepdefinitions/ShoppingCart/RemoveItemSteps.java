package com.stepdefinitions.ShoppingCart;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.WebDriver; 
import org.openqa.selenium.chrome.ChromeDriver; 
import com.pages.RLL_240Testing_BooksWagon_ShoppingCart.RemoveItem; 

import io.cucumber.java.Before; 
import io.cucumber.java.en.Given; 
import io.cucumber.java.en.Then; 
import io.cucumber.java.en.When; 

public class RemoveItemSteps { 
	WebDriver driver; 
	RemoveItem ri;
	Logger log25;
	private boolean isItemRemoved;
	private Object cartItemCount;

	@Before 
	public void init() { 
		driver = new ChromeDriver(); 
		ri = new RemoveItem(driver);
		log25=Logger.getLogger(RemoveItemSteps.class);
	} 

	@Given ("the user has added an item to the shopping cart") 
	public void the_user_has_added_an_item_to_the_shopping_cart() { 
		log25.info("user added item to the shopping cart");


	} 
	@When ("the user clicks on the shopping cart icon") 
	public void the_user_clicks_on_the_shopping_cart_icon() throws InterruptedException { 
		ri.cartIcon(); 
		log25.info(RemoveItemSteps.class);
		

	} 
	@When ("the user clicks on the Remove button next to the item") 
	public void the_user_clicks_on_the_Remove_button_next_to_the_item() throws InterruptedException { 
		ri.removeButton(); 

	} 
	@When ("the item should be removed from the shopping cart") 
	public void the_item_should_be_removed_from_the_shopping_cart() {
		Assert.assertTrue("Item was not removed from the cart", isItemRemoved);
		log25.info("Item removed from the cart");

	} 
	@Then ("the shopping cart should be updated accordingly") 
	public void the_shopping_cart_should_be_updated_accordingly() { 
		  Assert.assertEquals("Shopping cart was not updated correctly", 0, cartItemCount);

	} 
} 

