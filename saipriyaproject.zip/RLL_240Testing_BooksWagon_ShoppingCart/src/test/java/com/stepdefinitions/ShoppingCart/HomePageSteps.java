package com.stepdefinitions.ShoppingCart;

import java.util.NoSuchElementException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver; 
import org.testng.Assert; 

import com.pages.RLL_240Testing_BooksWagon_ShoppingCart.HomePage; 
import com.pages.RLL_240Testing_BooksWagon_ShoppingCart.NavigateUrl; 

import io.cucumber.java.Before; 
import io.cucumber.java.en.Given; 
import io.cucumber.java.en.Then; 
import io.cucumber.java.en.When; 

public class HomePageSteps { 
	WebDriver driver; 
	HomePage hp; 
	Logger log22; 

	@Before 
	public void init() { 
		driver = new ChromeDriver(); 
		hp = new HomePage(driver); 
		log22 = Logger.getLogger(HomePageSteps.class); 

	} 

	@Given ("user should be in home page") 
	public void user_should_be_in_home_page() { 
		hp.launch(); 
		log22.info("user is on the home page");
		

	} 
	@When ("user click on my account") 
	public void user_click_on_my_account() { 
		hp.Click_MyAccount(); 

	} 
	@Then ("user should be navigated to the My Account page") 
	public void user_should_be_navigated_to_the_My_Account_page() { 
		String expectedUrl = "https://www.bookswagon.com/myaccount"; 
		String actualUrl = driver.getCurrentUrl(); 
		Assert.assertEquals(actualUrl, expectedUrl, "User is not navigated to the My Account page");
		// Optionally, assert that a specific element on the My Account page is displayed
		try {
		WebElement accountHeading = driver.findElement(By.xpath("//h1[text()='My Account']")); // Replace with actual locator
		Assert.assertTrue(accountHeading.isDisplayed(),"My Account heading is not displayed.");
		} catch (NoSuchElementException e) {
		Assert.fail("My Account heading element is not found.");
		}
		log22.info("user navigated to My Account page"); 

	} 
} 

