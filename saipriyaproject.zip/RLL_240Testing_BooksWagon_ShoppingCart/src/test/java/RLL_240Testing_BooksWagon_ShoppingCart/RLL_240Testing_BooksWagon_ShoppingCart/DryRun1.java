package RLL_240Testing_BooksWagon_ShoppingCart.RLL_240Testing_BooksWagon_ShoppingCart;

import org.openqa.selenium.WebDriver; 
import org.openqa.selenium.chrome.ChromeDriver; 

import com.pages.RLL_240Testing_BooksWagon_ShoppingCart.AddingItemtoShoppingCart; 
import com.pages.RLL_240Testing_BooksWagon_ShoppingCart.HomePage; 
import com.pages.RLL_240Testing_BooksWagon_ShoppingCart.LoginPage; 
import com.pages.RLL_240Testing_BooksWagon_ShoppingCart.RemoveItem; 
import com.pages.RLL_240Testing_BooksWagon_ShoppingCart.NavigateUrl; 



public class DryRun1 { 
	public static void main(String[] args) throws InterruptedException  { 
		// TODO Auto-generated method stub 

		WebDriver driver; 
		driver= new ChromeDriver(); 

		HomePage hp = new HomePage(driver); 
		hp.launch(); 
		hp.Click_MyAccount(); 

		LoginPage lp = new LoginPage(driver); 
		lp.enter_emailfield("8179477480"); 
		lp.enter_password("Sai@1234"); 
		lp.click_submitButtton(); 

		NavigateUrl nu = new NavigateUrl(driver); 
		nu.Navigate(); 

		AddingItemtoShoppingCart ac = new AddingItemtoShoppingCart(driver); 
		ac.ClickBookName(); 
		ac.addItemToCart(); 

		RemoveItem ri = new RemoveItem(driver);	 
		ri.cartIcon(); 
		ri.removeButton(); 



	}		 
} 
